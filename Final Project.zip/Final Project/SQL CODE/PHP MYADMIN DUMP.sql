-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 07, 2017 at 09:42 PM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spritemo_cse345`
--

-- --------------------------------------------------------

--
-- Table structure for table `ENGLISH_PARAGRAPH`
--

CREATE TABLE IF NOT EXISTS `ENGLISH_PARAGRAPH` (
  `ENG_PARA_ID` int(11) NOT NULL,
  `CONTENT` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ENGLISH_PARAGRAPH`
--

INSERT INTO `ENGLISH_PARAGRAPH` (`ENG_PARA_ID`, `CONTENT`) VALUES
(1000, '<p><b>My Old Fashioned Father</b></p>\n\n<p>My father, though he is only in his early fifties, is stuck in his old-fashioned ways. He has a (1) general mistrust of any innovation or technology that he can&rsquo;t immediately grasp and he always tells us, that (2) if something isn&rsquo;t broken, then you shouldn&rsquo;t fix it.</p>\n\n<p>He has run (3) a small grocery store in town, and if you were to look at a snapshot of his back office taken when he opened the store in 1975, you would see that not much has changed since. (4) He is the most disorganized person I know and still uses a pencil and paper to keep track of his inventory. (5) His small office is about to burst with all the various documents, notes, and receipts he has accumulated over the years, his filing cabinets (6) have long since been filled up. The centerpiece of all the clutter is his ancient typewriter, which isn&rsquo;t even electric. In the past few years, Father&rsquo;s search for replacement typewriter ribbons has become an increasingly difficult task, because they are no longer being produced. He is perpetually tracking down the few remaining places that still have these antiquated ribbons in their dusty inventories. When people ask him why he doesn&rsquo;t upgrade his equipment, he tells them, &ldquo;Electric typewriters won&rsquo;t work in a blackout. All I need is a candle and some paper, and I&rsquo;m fine.&rdquo; Little does Father know, however, is that (7) the &ldquo;upgrade&rdquo; people are speaking of is not to an electric typewriter but to a computer.</p>\n\n<p>[1] Hoping to bring Father out of the dark ages, my sister, and I (8) bought him a brand new computer for his fiftieth birthday. [2] We offered to help him to transfer all of his records onto it and to teach him how to use it. [3] Eagerly, (9) we told him about all the new spreadsheet programs that would help simplify his recordkeeping and organize his accounts; and (10) emphasized the advantage of not having to completely retype any document when he found a typo. [4] Rather than offering us a look of joy for the life-changing gift we had presented him, however, he again brought up the blackout scenario. [5] To Father, this is a concrete argument, never mind the fact that (11) our town hasn&rsquo;t had a blackout in five years, and that one only lasted an hour or two. (12)</p>\n\n<p>My father&rsquo;s state-of-the-art computer now serves as a very expensive bulletin board for the hundreds of adhesive notes he uses to keep himself organized. Sooner than later, (13) we fully expect it will completely disappear under the mounting files and papers in the back office. In the depths of that disorganized office, the computer will join the cell phone my mom gave him a few years ago. (14) Interestingly enough, every once in a while, that completely forgotten cell phone will ring from under the heavy clutter of the past. (15)</p>'),
(1001, '<p><b>The Speed of Sound</b></p>\r\n\r\n<p>The term &ldquo;supersonic&rdquo; refers to anything that travels faster than the speed of sound. When the last of the supersonic Concorde passenger planes made its final trip across the Atlantic in November of 2003, an interesting (1) chapter in history was finally closed. The fleet of supersonic Concorde SSTs, or &ldquo;Supersonic Transports,&rdquo; which were jointly operated by Air France and British Airways, has been making the Intercontinental trip across the Atlantic for almost thirty years. These amazing machines cruised at Mach 2 which is (2) more than twice the speed of sound. They flew to a height (3) almost twice that of standard passenger airplanes. The Concorde routinely made the trip from New York to London in less than three hours and was much more expensive than normal transatlantic flights. Though the majority of the passengers who traveled on the Concorde were celebrities or the extremely wealthy, it also attracted ordinary people who simply wanted to know how it felt to travel faster than the speed of sound. Some of these, (4) would save money for years just to gain that knowledge.</p>\r\n\r\n<p>What is the speed of sound? Many people are surprised to learn that there is no fixed answer to this question. The speed that (5) sound travels through a given medium depends on a number of factors. So that we may better begin to understand (6) the speed of sound, we must first understand what a &ldquo;sound&rdquo; really is.</p>\r\n\r\n<p>The standard dictionary definition of sound is &ldquo;a vibration or disturbance transmitted, like waves through water, through a material medium such as a gas.&rdquo; Our ears are able to pick up those sound waves and convert (7) them into what we hear. This means that the speed at which sound travels through gas directly depends on what gas it is traveling through, and the temperature and pressure of the gas. (8) When discussing aircraft breaking the speed of sound, that gas medium, of course, is air. As air temperature and pressure decrease with altitude (9), so does the speed of sound. An airplane flying at the speed of sound at sea level is traveling roughly at 761 mph; however (10) when that same plane climbs to 20,000 feet, the speed of sound is only about 707 mph. This is why the Concorde&rsquo;s cruising altitude was so much higher than that of a regular passenger aircraft; planes can reach supersonic speeds more easily at higher altitudes. (11)</p>\r\n\r\n<p>In the years since the Concorde has been (12) decommissioned, only fighter pilots and astronauts have been able to experience the sensation of breaking &ldquo;the sound barrier.&rdquo; But that is all about to change very soon. (13) Newer and faster supersonic passenger planes are being developed that will be technologically superior to the Concorde and much cheaper to operate. That means we can expect that in the very near future, (14) supersonic passenger travel will be available not only to the rich and famous, but also be for (15) the masses, so they, too, can experience life at speeds faster than the speed of sound.</p>'),
(1002, '<p><b>Good Beekeeping<b/></p>\r\n\r\n<p>It is generally not widely known that beekeeping is an important industry in the United States and that (1) America are known (2) not just for the quantity but also for (3) the quality of the honey it produces. This is the case, however, and America has long been recognized by other countries worldwide as an important producer of honey, although (4) beekeepers are found in every state, Ohio, Indiana and Illinois (5) produce large quantities of fine honey, as does Texas and California.</p>\r\n\r\n<p>One of the most important things for beekeepers to do, in order to have a successful bee colony that would provide (6) lots of honey, is to make sure the bees have adequate shelter during cold weather, and also from the intense heat of summer. (7) In the Northern and Central states good protection must also become (8) provided against zero weather, since bees are not used to frozen temperatures! Though, (9) honeybees originally came from the tropical climates of Southeast Asia, more specifically the Philippines and surrounding areas, ample protection is required for them. (10)</p>\r\n\r\n<p>The hives must have (11) an outer case placed around them and then have leaves, or straw or sawdust (12) packed around them for insulation. Set up in this way, they will withstand even an arctic winter. Perhaps at no time is protection more necessary than in early spring when the hives are full of young, baby (13) bees. During this time, hives may also be covered with layers of thick paper. A small hole cut in the paper will allow all of the fresh air necessary for bees in a state of sleep.</p>\r\n\r\n<p>It has become increasingly important (14) to protect existing hives, as the American honeybee population has declined significantly over the past 10 years. Scientists do not know exactly why the honeybees are dying, but some believe a mysterious virus has killed off over 40% of the total honeybee population. Others argue that pesticides and other environmental toxins have affected the bees. [15]</p>');

-- --------------------------------------------------------

--
-- Table structure for table `ENGLISH_PROB`
--

CREATE TABLE IF NOT EXISTS `ENGLISH_PROB` (
  `ENG_PROB_ID` int(11) NOT NULL,
  `PROB_ID` int(11) NOT NULL,
  `ENG_PARA_ID` int(11) NOT NULL,
  `PROB_QUESTION` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PROB_CHOICE_1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PROB_CHOICE_2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PROB_CHOICE_3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PROB_ANSWER` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ENGLISH_PROB`
--

INSERT INTO `ENGLISH_PROB` (`ENG_PROB_ID`, `PROB_ID`, `ENG_PARA_ID`, `PROB_QUESTION`, `PROB_CHOICE_1`, `PROB_CHOICE_2`, `PROB_CHOICE_3`, `PROB_ANSWER`) VALUES
(1, 100, 1000, '(1)', 'WAYS HE HAS A', 'WAYS HAVING A', 'WAYS, AND STILL HAS A', 'NO CHANGE'),
(2, 100, 1000, '(2)', 'NO CHANGE', 'tell us, that,', 'tell us that', 'TELL US THAT'),
(3, 100, 1000, '(3)', 'NO CHANGE', 'WAS RUNNING', 'ran', 'RUNS'),
(4, 100, 1000, '(4)', 'NOT CHANGE VERY MUCH', 'NOT BE LIKELY TO SEE VERY MUCH THAT HAS CHANGED SINCE', 'BE ABLE TO SEE RIGHT AWAY THAT NOT VERY MUCH HAS CHANGED SINCE', 'NO CHANGE'),
(5, 100, 1000, 'Assuming that all are true, which of the following replacements for “inventory” would be most appropriate in context?', 'inventory of canned and dry goods.', 'inventory, which he writes down by hand. ', 'inventory of goods on the shelves and in the storeroom.', 'inventory, refusing to consider a more current method.'),
(6, 100, 1000, '(6)', 'NO CHANGE', 'years, and besides that, his filing cabinets', 'years and since his filing cabinets', 'years; besides that, his filing cabinets'),
(7, 100, 1000, '(7)', 'NO CHANGE', 'know, besides, that', 'know, beyond that,', 'know, however, that'),
(8, 100, 1000, '(8)', 'NO CHANGE', 'me and my sister', 'my sister and I,', 'my sister and I'),
(9, 100, 1000, '(9)', 'On the other hand,', 'In addition', 'Rather,', 'NO CHANGE'),
(10, 100, 1000, '(10)', 'NO CHANGE', 'accounts and,', 'accounts, we', 'accounts and'),
(11, 100, 1000, '(11)', 'although,', 'NO CHANGE', 'despite the fact that ', 'although'),
(12, 100, 1000, 'The author wants to include the following statement in this paragraph:\n\nWe expected it to save him a lot of time and effort.\n\nThe most logical placement for this sentence would be:', 'after Sentence 4', 'after Sentence 5', 'before Sentence 1', 'after Sentence 1'),
(13, 100, 1000, '(13)', 'As soon as later,', 'Sooner rather than later,', 'NO CHANGE', 'Sooner or later,'),
(14, 100, 1000, '(14)', 'Deep in the disorganization of that office’s, the computer will join the cell phone my mom gave him a few years back.', 'In the disorganized depths of the office, the computer will soon be joined by the cell phone my mom gave him a few years ago.', 'The computer will join the cell phone my mom gave him a few years back in the disorganized depths of that office.', 'NO CHANGE'),
(15, 100, 1000, 'Which of the following would provide the most appropriate conclusion for the passage? ', 'We have no idea who might be calling.', 'Maybe one day I will try to find it and answer it.', 'It’s hard to say what else might be lost in there.', 'We tell my father it’s a reminder that he can’t hide from the future forever. '),
(16, 101, 1001, '(1)', 'November, of 2003 an interesting', 'November of 2003 an interesting', 'November of 2003; an interesting ', 'NO CHANGE'),
(17, 101, 1001, '(2)', 'Mach 2, which', 'a speed of Mach 2, which is', 'NO CHANGE', 'Mach 2, '),
(18, 101, 1001, '(3)', 'NO CHANGE', 'toward an altitude', 'very high', 'at an altitude'),
(19, 101, 1001, '(4)', 'NO CHANGE', 'Among these were those who', 'Some,', 'Some'),
(20, 101, 1001, '(5) ', 'NO CHANGE', 'to which', 'where', 'at which'),
(21, 102, 1002, '(1)', 'and', 'that', 'but', 'NO CHANGE'),
(22, 102, 1002, '(2)', 'were known', 'was known', 'NO CHANGE', 'is known'),
(23, 102, 1002, '(3)', 'NO CHANGE', 'not only for the quantity but for', 'not just for the quantity but also for', 'not only for the quantity but also for'),
(24, 102, 1002, '(4)', 'NO CHANGE', 'YET', 'HENCE', 'AND'),
(25, 102, 1002, 'NO CHANGE', 'state; Ohio, and Indiana, and Illinois', 'state—Ohio, Indiana and Illinois', 'NO CHANGE', 'state; Ohio, Indiana, and Illinois');

-- --------------------------------------------------------

--
-- Table structure for table `PARAGRAPH`
--

CREATE TABLE IF NOT EXISTS `PARAGRAPH` (
  `PARA_ID` int(11) NOT NULL,
  `CONTENT` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `PRACTICE`
--

CREATE TABLE IF NOT EXISTS `PRACTICE` (
  `PRAC_ID` int(11) NOT NULL,
  `STU_ID` int(11) NOT NULL,
  `PRAC_DATETIME` datetime DEFAULT NULL,
  `PRAC_DIFF` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRAC_RESULT` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRAC_SUBJECT` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `PROBLEM`
--

CREATE TABLE IF NOT EXISTS `PROBLEM` (
  `PROB_ID` int(11) NOT NULL,
  `PROB_TYPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `DIFF_LEVEL` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `PROBLEM`
--

INSERT INTO `PROBLEM` (`PROB_ID`, `PROB_TYPE`, `DIFF_LEVEL`) VALUES
(100, 'ENG', 'E'),
(101, 'ENG', 'M'),
(102, 'ENG', 'H'),
(200, 'READING', 'E'),
(201, 'READING', 'M'),
(202, 'READING', 'H');

-- --------------------------------------------------------

--
-- Table structure for table `READING_PROB`
--

CREATE TABLE IF NOT EXISTS `READING_PROB` (
  `PROB_ID` int(11) NOT NULL,
  `PARA_ID` int(11) NOT NULL,
  `PROB_CHOICE_1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PROB_CHOICE_2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PROB_CHOICE_3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PROB_ANSWER` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `STUDENT`
--

CREATE TABLE IF NOT EXISTS `STUDENT` (
  `STU_ID` int(11) NOT NULL,
  `STU_FNAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `STU_LNAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `STU_ADDRESS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `STU_CITY` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `STU_STATE` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `STU_ZIP` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `STU_EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `STU_PASSWORD` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `STUDENT`
--

INSERT INTO `STUDENT` (`STU_ID`, `STU_FNAME`, `STU_LNAME`, `STU_ADDRESS`, `STU_CITY`, `STU_STATE`, `STU_ZIP`, `STU_EMAIL`, `STU_PASSWORD`) VALUES
(1, 'Brandon', 'Nolan', '123 NoWhere St.', 'Detroit', 'MI', '48127', 'bnolan@preparetestcse345.co', '6c29df5275f8bf08d369c7828c1414d6'),
(2, 'ANDREW', 'ALISA', '30205 ALGER', 'MADISON HEIGHTS', 'MI', '48071', 'ANDREWKALISA@GMAIL.COM', '3c086f596b4aee58e1d71b3626fefc87'),
(3, 'ANDREW', 'ALISA', '2200 SQUIRREL ROAD', 'ROCHESTER', 'MI', '48326', 'AKALISA@OAKLAND.EDU', '3c086f596b4aee58e1d71b3626fefc87'),
(4, 'ANDREW', 'ALISA', '183 TACOMA', 'TROY', 'MI', '48084', 'AALISA@RECRUITUS.NET', '36f4cd1bef09ffcf9520dad985f8fc55'),
(5, 'ANDREW', 'ALISA', '30205 ALGER', 'MADISON HEIGHTS', 'MI', '48071', 'SPRITEMONEY@YAHOO.COM', '3c086f596b4aee58e1d71b3626fefc87'),
(9, 'KANYE', 'WEST', '123 NOWHERE', 'LA', 'CA', '99999', 'RUSUPERTODAY@YAHOO.COM', '5f4dcc3b5aa765d61d8327deb882cf99'),
(10, 'VAL', 'H', '2200 N SQUIRREL ROAD', 'ROCHESTER', 'MI', '48326', 'VALLY@MAILINATOR.COM', '3a6d0284e743dc4a9b86f97d6dd1a3bf');

-- --------------------------------------------------------

--
-- Table structure for table `TEMP_STUDENT`
--

CREATE TABLE IF NOT EXISTS `TEMP_STUDENT` (
  `STU_ID` int(11) NOT NULL,
  `STU_FNAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `STU_LNAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `STU_ADDRESS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `STU_CITY` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `STU_STATE` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `STU_ZIP` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `STU_EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `STU_PASSWORD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `STU_KEY` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `TEMP_STUDENT`
--

INSERT INTO `TEMP_STUDENT` (`STU_ID`, `STU_FNAME`, `STU_LNAME`, `STU_ADDRESS`, `STU_CITY`, `STU_STATE`, `STU_ZIP`, `STU_EMAIL`, `STU_PASSWORD`, `STU_KEY`) VALUES
(34, 'JOHN', 'Q', '450 NOWHERE BLVD', 'DETROIT', 'MI', '48212', 'NOTMARINE@MAILINATOR.COM', '1a1dc91c907325c69271ddf0c944bc72', '4bde7fcdf4147cd66189b4f0c47ddd0b');

-- --------------------------------------------------------

--
-- Table structure for table `TEST`
--

CREATE TABLE IF NOT EXISTS `TEST` (
  `TEST_ID` int(11) NOT NULL,
  `STU_ID` int(11) NOT NULL,
  `TEST_DATE` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `TEST`
--

INSERT INTO `TEST` (`TEST_ID`, `STU_ID`, `TEST_DATE`) VALUES
(1, 1, '2017-04-07 17:30:33'),
(2, 1, '2017-04-07 18:30:33');

-- --------------------------------------------------------

--
-- Table structure for table `TEST_ITEM`
--

CREATE TABLE IF NOT EXISTS `TEST_ITEM` (
  `ITEM_ID` int(11) NOT NULL,
  `TEST_ID` int(11) NOT NULL,
  `PROB_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `TEST_ITEM`
--

INSERT INTO `TEST_ITEM` (`ITEM_ID`, `TEST_ID`, `PROB_ID`) VALUES
(1, 1, 100),
(2, 2, 101);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ENGLISH_PARAGRAPH`
--
ALTER TABLE `ENGLISH_PARAGRAPH`
  ADD PRIMARY KEY (`ENG_PARA_ID`);

--
-- Indexes for table `ENGLISH_PROB`
--
ALTER TABLE `ENGLISH_PROB`
  ADD PRIMARY KEY (`ENG_PROB_ID`);

--
-- Indexes for table `PARAGRAPH`
--
ALTER TABLE `PARAGRAPH`
  ADD PRIMARY KEY (`PARA_ID`);

--
-- Indexes for table `PRACTICE`
--
ALTER TABLE `PRACTICE`
  ADD KEY `STU_ID` (`STU_ID`);

--
-- Indexes for table `PROBLEM`
--
ALTER TABLE `PROBLEM`
  ADD PRIMARY KEY (`PROB_ID`);

--
-- Indexes for table `READING_PROB`
--
ALTER TABLE `READING_PROB`
  ADD PRIMARY KEY (`PROB_ID`), ADD KEY `PARA_ID` (`PARA_ID`);

--
-- Indexes for table `STUDENT`
--
ALTER TABLE `STUDENT`
  ADD PRIMARY KEY (`STU_ID`);

--
-- Indexes for table `TEMP_STUDENT`
--
ALTER TABLE `TEMP_STUDENT`
  ADD PRIMARY KEY (`STU_ID`);

--
-- Indexes for table `TEST`
--
ALTER TABLE `TEST`
  ADD PRIMARY KEY (`TEST_ID`), ADD KEY `STU_ID` (`STU_ID`);

--
-- Indexes for table `TEST_ITEM`
--
ALTER TABLE `TEST_ITEM`
  ADD PRIMARY KEY (`ITEM_ID`), ADD KEY `PROB_ID` (`PROB_ID`), ADD KEY `TEST_ID` (`TEST_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `STUDENT`
--
ALTER TABLE `STUDENT`
  MODIFY `STU_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `TEMP_STUDENT`
--
ALTER TABLE `TEMP_STUDENT`
  MODIFY `STU_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
