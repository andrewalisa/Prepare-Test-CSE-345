###################
What is Prepare Test CSE 345?
###################

This is a project for my Databases course at Oakland University. It allows students to Prepare for their English/Reading tests.
Not intended for actual use.

*******************
My Teammates 
*******************
- Andrew Alisa - Project Leader 
- Larisa Garmo - Helped out with the designing 
- Valerie Jarbo - Helped out with the overall execution

***************
Acknowledgement
***************

I would like to thank the entire CodeIgniter team. This was my first time using CodeIgniter. I learned a lot about PHP, MySQL and Web Development. I learned that CodeIgniter is an awesome PHP framework. 
