1. All of the source code is in there. 
	The best way to see it in action is to visit: http://preparetestcse345.co/
	You have to create an account, but I can provide you a username and password of a current one that you could use.
	
	email: bnolan@preparetestcse345.co
	password: goodlife 

2. If you create an account, it will take some time to receive a confirmation email. I am not sure why it does that (probably the email providers checking if it isn't spam). The confirmation emails 
they DO WORK, I have tested it plenty of times. It takes some time to receive the email. 

3. I have provided the SQL Code of when I initially created the tables. I also did a dump from PHPMyadmin.

4. Folder structures: SQL CODE contains the SQL Code. The Visio Drawing Folder creates our final diagram, in crow foot's notation. 
	The folder structed "website" contains our website in a zip folder. This is the source code of our website. 
5. Technologies I used: Code Igniter, a PHP Framework along with MYSQL. 

6. Please let me know if you have any additional questions. 


Group #1: Andrew Alisa, Larisa Garmo, Valerie Jarbo. 

Andrew -> Group Lead. Did the PHP Programming. 
Larisa Garmo -> In charge of the design. Helped with the SQL Code
Valerie Jarbo -> Execution Manager. She helped out with the SQL Code, and the website as well.

Required Functions completed: 

- A student can sign up for our website, with the proper validations in place.
- BONUS: We included a confirmation email. 
- A student may not access the portal page unless if they are logged in.
- A student may log in, after they register.
- After the student logs in, they may choose the subject: English or Reading.
- Once the student chooses the subject, they can choose a difficulty level. Easy, Medium, or Hard.
- The student can take a simulated exam, and answer the questions. 
- The test results are immediately available to the student after they are done answering the questions, along with studying recommendations. 


Incomplete Functions:

- I did not have enough time to implement the previous practice activities. I have started on this, but I did not get it to an appropriate level for execution.
