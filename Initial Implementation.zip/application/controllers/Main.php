<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	//This Controller loads the Main_Page view.
	public function index()
	{
		$this->load->view('main_page');
	}
	
	//Loads the portal view
	public function portal() {
		$this->load->view('portal_page'); 
	}
	
	//This controller valides the login page
	public function login_validation() {
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email', 'Email', 'required|trim|callback_validate_credentials');
		$this->form_validation->set_rules('password', 'Password', 'required|md5');
		
		if ($this->form_validation->run()){
			redirect('main/portal');
		} else {
			$this->load->view('main_page'); 
		}
	}
	
	public function validate_credentials() {
		$this->load->model('model_users');
		
		if ($this->model_users->can_log_in()){
			return true;
		} else {
			$this->form_validation->set_message('validate_credentials', 'Incorrect username/password.');
			return false;
		}
	}
}
